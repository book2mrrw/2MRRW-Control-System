# Recovery checkpoint: checkpoint-20260522-142635

**Created:** 2026-05-22T19:26:35Z  
**Tag:** `checkpoint-20260522-142635`  
**Branch:** `main`  
**Commit:** `d1680f425c79027779eac6b1fde1914e3258dcfb`  
**Subject:** feat: mobile nav consolidation + admin login + scroll fix + release date

## Note

Manual recovery checkpoint

## Restore this checkpoint

```bash
git fetch --tags origin
git checkout checkpoint-20260522-142635
npm ci
npm run verify
./scripts/check-architecture-guardrails.sh
```

## Deploy (if promoting to production)

```bash
npx vercel --prod --yes
```

See [CHECKPOINT_WORKFLOW.md](../RECOVERY_GUIDES/CHECKPOINT_WORKFLOW.md).
