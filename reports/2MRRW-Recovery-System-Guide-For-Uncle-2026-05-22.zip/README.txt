2MRRW recovery setup guide for Uncle — no secrets.
Start with UNCLE_RECOVERY_SETUP_GUIDE.md
